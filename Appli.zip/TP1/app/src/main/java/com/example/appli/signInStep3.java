package com.example.appli;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.Switch;

public class signInStep3 extends AppCompatActivity {

    ImageButton btn_close;
    Switch btn_switch;
    LinearLayout opt_com;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in_step3);

        btn_close = (ImageButton)findViewById(R.id.headClose);
        btn_switch = (Switch)findViewById(R.id.btn_cni);
        opt_com = (LinearLayout)findViewById(R.id.opt_com);


        btn_switch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    opt_com.setVisibility(View.VISIBLE);
                } else {
                    opt_com.setVisibility(View.GONE);
                }
            }
        });
    }
}

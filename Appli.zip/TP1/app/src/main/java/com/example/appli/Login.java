package com.example.appli;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.ActivityOptions;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.InputType;
import android.transition.Fade;
import android.util.Pair;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;

public class Login extends AppCompatActivity {

    EditText password;
    Button btn_create;

    private RelativeLayout relativeLayout;
    private Button btn_connexion, btn_facebook, btn_google;

    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        Fade fade = new Fade();
        View decor = getWindow().getDecorView();
        fade.excludeTarget(decor.findViewById(R.id.bg), true);
        fade.excludeTarget(decor.findViewById(R.id.imgBg), true);
        fade.excludeTarget(android.R.id.statusBarBackground, true);
        fade.excludeTarget(android.R.id.navigationBarBackground, true);

        getWindow().setEnterTransition(fade);
        getWindow().setExitTransition(fade);

        password = (EditText)findViewById(R.id.password);
        btn_create = (Button) findViewById(R.id.create_account);

        relativeLayout = (RelativeLayout)findViewById(R.id.connection_mode);
        btn_connexion = (Button)findViewById(R.id.btn_connexion);
        btn_facebook = (Button)findViewById(R.id.btn_facebook);
        btn_google = (Button) findViewById(R.id.btn_google);


        password.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {

                final int DRAWABLE_LEFT = 0;
                final int DRAWABLE_TOP = 1;
                final int DRAWABLE_RIGHT = 2;
                final int DRAWABLE_BOTTOM = 3;
                if(event.getAction() == MotionEvent.ACTION_UP) {
                    if(event.getRawX() >= (password.getRight() - password.getCompoundDrawables()[DRAWABLE_RIGHT].getBounds().width())) {
                        // your action here
                        if(password.getInputType() == 144)
                        password.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
                        Drawable img = password.getContext().getResources().getDrawable( R.drawable.ic_visibility_off);
                        password.setHint("Mot de passe");
                        password.setCompoundDrawablesWithIntrinsicBounds(null , null, img, null);
                        return true;
                    }
                }
                return false;
            }
        });

        final Pair[] pairs = new Pair[4];
        pairs[0] = new Pair<View, String>(btn_facebook, "fbTransition");
        pairs[1] = new Pair<View, String>(btn_google, "ggTransition");
        pairs[2] = new Pair<View, String>(relativeLayout, "rlTransition");
        pairs[3] = new Pair<View, String>(btn_connexion, "conTransition");

        btn_create.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), LoginWelcome.class);
                ActivityOptions options = ActivityOptions.makeSceneTransitionAnimation(Login.this, pairs);
                startActivity(intent);
            }
        });

    }
}

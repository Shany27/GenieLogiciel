package com.example.appli;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class SplashScren extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_scren);
    }
}

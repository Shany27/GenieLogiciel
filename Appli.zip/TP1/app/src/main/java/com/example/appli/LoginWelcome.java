package com.example.appli;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ActivityOptions;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.transition.Fade;
import android.util.Pair;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class LoginWelcome extends AppCompatActivity {

    private RelativeLayout relativeLayout;

    private Button btn_connexion, btn_facebook, btn_google;
    private TextView have_account;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_welcome);

        Fade fade = new Fade();
        View decor = getWindow().getDecorView();
        fade.excludeTarget(decor.findViewById(R.id.bg), true);
        fade.excludeTarget(decor.findViewById(R.id.imgBg), true);
        fade.excludeTarget(android.R.id.statusBarBackground, true);
        fade.excludeTarget(android.R.id.navigationBarBackground, true);

        getWindow().setEnterTransition(fade);
        getWindow().setExitTransition(fade);


        relativeLayout = (RelativeLayout)findViewById(R.id.connection_mode);
        btn_connexion = (Button)findViewById(R.id.btn_connexion);
        btn_facebook = (Button)findViewById(R.id.btn_facebook);
        btn_google = (Button) findViewById(R.id.btn_google);
        have_account = (TextView) findViewById(R.id.already_account);

        final Pair[] pairs = new Pair[5];
        pairs[0] = new Pair<View, String>(btn_facebook, "fbTransition");
        pairs[1] = new Pair<View, String>(btn_google, "ggTransition");
        pairs[2] = new Pair<View, String>(relativeLayout, "rlTransition");
        pairs[3] = new Pair<View, String>(btn_connexion, "conTransition");
        pairs[4] = new Pair<View, String>(have_account, "acTransition");


        btn_connexion.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), signInStep3.class);
                startActivity(intent);
            }
        });

        have_account.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), Login.class);
                ActivityOptions options = ActivityOptions.makeSceneTransitionAnimation(LoginWelcome.this, pairs);
                startActivity(intent, options.toBundle());
            }
        });




    }
}
